<?php

namespace Illuminate\Foundation\Events;

class MaintenanceModeEnabled
{
    //
}
