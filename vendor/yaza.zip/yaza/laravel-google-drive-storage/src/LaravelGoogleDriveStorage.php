<?php

namespace Yaza\LaravelGoogleDriveStorage;

class LaravelGoogleDriveStorage
{
}
