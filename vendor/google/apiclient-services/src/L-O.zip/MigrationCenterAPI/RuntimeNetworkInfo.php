<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\MigrationCenterAPI;

class RuntimeNetworkInfo extends \Google\Model
{
  protected $connectionsType = NetworkConnectionList::class;
  protected $connectionsDataType = '';
  public $connections;
  /**
   * @var string
   */
  public $netstat;
  protected $netstatTimeType = DateTime::class;
  protected $netstatTimeDataType = '';
  public $netstatTime;

  /**
   * @param NetworkConnectionList
   */
  public function setConnections(NetworkConnectionList $connections)
  {
    $this->connections = $connections;
  }
  /**
   * @return NetworkConnectionList
   */
  public function getConnections()
  {
    return $this->connections;
  }
  /**
   * @param string
   */
  public function setNetstat($netstat)
  {
    $this->netstat = $netstat;
  }
  /**
   * @return string
   */
  public function getNetstat()
  {
    return $this->netstat;
  }
  /**
   * @param DateTime
   */
  public function setNetstatTime(DateTime $netstatTime)
  {
    $this->netstatTime = $netstatTime;
  }
  /**
   * @return DateTime
   */
  public function getNetstatTime()
  {
    return $this->netstatTime;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(RuntimeNetworkInfo::class, 'Google_Service_MigrationCenterAPI_RuntimeNetworkInfo');
